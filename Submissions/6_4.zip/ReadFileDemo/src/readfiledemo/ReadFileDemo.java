/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readfiledemo;

import java.io.*;

/**
 *
 * @author S528754
 */
public class ReadFileDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String [] args) {

        String fileName = "C:\\Users\\s528754\\Documents\\NetBeansProjects\\ReadFileDemo\\temp.txt";

        String line = null;

        try {
            FileReader fileReader = 
                new FileReader(fileName);

            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }   
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");        
        }
    }  
}
