/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addAllnumbers;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author S528754
 */
public class AddAllNumbers {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
        // TODO code application logic here
        public static void main(String[] args) throws IOException {

        Scanner s = new Scanner(new File("input.txt"));
        int sum = 0;
            while(s.hasNextInt()) {
                sum = sum + s.nextInt();
            }
        System.out.println(sum);
    }   
}
