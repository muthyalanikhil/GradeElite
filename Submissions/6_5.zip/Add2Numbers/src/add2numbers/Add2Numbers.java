/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package add2numbers;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author S528754
 */
public class Add2Numbers {

    /**
     * @param args the command line arguments
     */
        // TODO code application logic here
        public static void main(String[] args) throws IOException {

        Scanner s = new Scanner(new File("input.txt"));
        int num1 = s.nextInt();
        int num2 = s.nextInt();
        System.out.println(num1 + num2);
    }   
}
